'''
The largest possible number is 7*9!, since any number with 8 digits is far greater than 8*9!. More digits makes the problem worse.
'''

factorials = [1,1,2,6,24,120,720,5040,40320,362880] #precomputed table!
def factorialSum(n):
    return sum([factorials[int(ch)] for ch in str(n)])

accum = 0
for i in range(10,7*factorials[9]): #do not count single digits, start at 10
    if i == factorialSum(i):
        print(i)
        accum += i
print("sum")
print(accum)
