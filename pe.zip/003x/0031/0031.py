'''
(200p,100p,50p,20p,10p,5p,2p,1p)-tuple, each value how many coins

The 5-2 transition is decidedly nonwhole

split 10n into 2*5n and 5*2n
split 5n into 2*2n+1n
split 2n into 2*1n

this generates all combinations (some more than once)

very similar to p169 in concept, but not scale
'''

oldCombos = set() #stores all of the combos, old and new

currentCombos = set() #stores all of the combos that were created one round ago
newCombos = {(1,0,0,0,0,0,0,0)} #stores the combos that are newly created

print("counter must stabilize at 0")
while len(newCombos) > 0: #once no new combos are being added, stop
    
    print("run, new combos added:", len(newCombos)) 
    oldCombos = oldCombos.union(currentCombos) #add the combos that were just split
    currentCombos = set(newCombos) #time to split up new combos
    newCombos = set() #reset the list, populate with newly split combos
    
    for combo in currentCombos:
        for coinIndex in range(len(combo) - 1): #cannot split up a 1p coin
            #add a new combo to newCombos for every possible coin split
            
            if combo[coinIndex] > 0: #cannot split n-coin if none left

                if coinIndex % 3 == 0: #this is a 2n coin, split it and add the new combo to newCombos
                    newCombo = list(combo)
                    newCombo[coinIndex] -= 1
                    newCombo[coinIndex+1] += 2
                    newCombos.add(tuple(newCombo))
                elif coinIndex % 3 == 1: #this is a 10n coin, split it 2 different ways, and add new combos to newCombos
                    newCombo = list(combo)
                    newCombo[coinIndex] -= 1
                    newCombo[coinIndex+1] += 2
                    newCombos.add(tuple(newCombo))
                    newCombo = list(combo)
                    newCombo[coinIndex] -= 1
                    newCombo[coinIndex+2] += 5
                    newCombos.add(tuple(newCombo))
                else: #this is a 5n coin, split it and add the new combo to newCombos
                    newCombo = list(combo)
                    newCombo[coinIndex] -= 1
                    newCombo[coinIndex+1] += 2
                    newCombo[coinIndex+2] += 1
                    newCombos.add(tuple(newCombo))

print(len(oldCombos))
