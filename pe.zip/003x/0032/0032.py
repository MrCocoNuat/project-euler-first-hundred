'''
only 9-digit concatenations are useful

digit numbers:
1*3=5 is impossible
1*4=4 is possible
1*5=3 is impossible
2*2=5 is impossible
2*3=4 is possible
2*4=3 is impossible

so the only possible arrangements are
1*4=4, 2*3=4, and of course their commutations

Optimization: for a 1*4=4 arrangement, if A=:
1, the result is never pandigital (B repeated)
9, the result is never pandigital (9 repeated)
has repeating digits, result is not pandigital (duh)

naturally B can not have repeating digits either
'''

def subtract(lis,sub): #list subtraction pure function, assumes that everything in sub really is in lis
    return [i for i in lis if i not in sub]

digits = [z for z in range(1,10)] #generate 1-digit nonrepeating-digit numbers

panOne = {z:{z} for z in subtract(digits,[1,9])}
panTwo = {10*y+z:{y,z} for y in digits for z in subtract(digits,[y])}#two digit
panThree = {100*x+10*y+z:{x,y,z} for x in digits for y in subtract(digits,[x]) for z in subtract(digits,[x,y])}
panFour = {1000*w+100*x+10*y+z:{w,x,y,z} for w in digits for x in subtract(digits,[w]) for y in subtract(digits,[w,x]) for z in subtract(digits,[w,x,y])}

products = set()

def digitSet(n): #should only have 4 digit argument
    ans = set()
    while n > 0:
        ans.add(n % 10)
        n //= 10
    return ans

'''
Search starting with B, the 3 and 4 digit numbers. 
For the 4 digit case, this is easy,
'''

for b in panFour:
    for a in panOne:
        if a * b > 9999:
            continue
        if len(panFour[b].union(panOne[a]).union(digitSet(a*b)).union({0})) == 10: #without 0, the concatenation held all 9 digits
            products.add(a*b)
            print("%d x %d = %d" % (a, b, a*b))


'''
Now the 3 digit case, the same, essentially
'''

for b in panThree:
    for a in panTwo:
        if a * b > 9999:
            continue
        if len(panThree[b].union(panTwo[a]).union(digitSet(a*b)).union({0})) == 10:
            products.add(a*b)
            print("%d x %d = %d" % (a, b, a*b))


#print(products)

accum = 0
for product in products:
    accum += product

print(accum)
