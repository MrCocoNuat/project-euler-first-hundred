'''
brute force,
generate all of the pythagorean triple with p < 1001

using a = mm-nn, b = 2mn, c = mm+nn and m>n>0
then scaling up each primitive triple

This will generate unique triples if m or n is even and m coprime n

perimeter = k * 2m(m+n)

the largest m that needs to be considered is sqrt(500) < 25
'''

import math

dictPerims = {} #how many pythagorean triples with this perimeter?

for m in range(2,25):
    for n in range(1,m):
        if math.gcd(m,n) != 1 or m*n % 2 == 1:
            continue
        
        perim = 2*m*(m+n)
        k = 1
        while k*perim < 1001:
            dictPerims[k*perim] = dictPerims.get(k*perim,0) + 1
            k+=1
        
abundantPerim = 0 #perimeter with most triples
maxPerim = 0 #how many triples
for k in dictPerims.keys():
    if dictPerims[k] > maxPerim:
        abundantPerim = k
        maxPerim = dictPerims[k]

print(abundantPerim)
