#a cheap brute force

import math

num = 1; #the product numerator
den = 1; #the product denominator

for z in range(1,10): #the common digit, 0 excluded
    for x in range(0,10):
        for y in range(x+1,10): #There are seeminly eight fractions to check: xz/zy, zx/zy, xz/yz, zx/yz, and reciprocals. Since if one of these is curious, then its reciprocal is too, four are eliminated. xz/yz and zx/zy don't work ever (all trivial), leaving just two. Finally, if xz/zy is curious, zx/yz's reciprocal is too with a x-y swap, and so zx/yz is curious too. Only xz/zy needs to be checked, with the added condition that x<y, for example. Of course, if curious it will be equal to x/y.
            if (x*10*z == y*9*x+y*z):
                num *= x
                den *= y

print(den/math.gcd(num,den))
