'''
0,1,2,3,4,...^5 = 0,1,32,243,1024,3125,77776,16807,32768,59049

1 digit, no chance
2 digits, no (10,11,12,20,21,22)
3 digits, maybe
The smallest number that could be a fifth power sum is 3 digits

6 digits, maybe
7 digits, no (9999999 has largest digitpower sum, which is only 6 digits)
The largest number that could be a fifth power sum is 6 digits
'''

def fifthPowerSum(n):
    return sum([int(ch)**5 for ch in str(n)])

accum = 0
print("fifth power sum numbers:")
for i in range(100,999999):
    if i == fifthPowerSum(i):
        print(i)
        accum += i

print("sum")
print(accum)
