'''
converting from binary to decimal is a lot easier to write code for than the reverse...

1M in decimal is less than 100000000000000000000 in binary, 2^20
this is 21 bits, so only palindromes up to 20 bits are necessary
'''

def decimalIsPalindrome(n):
    return str(n) == str(n)[::-1]

def binToDec(b):
    result = 0
    for ch in b[::-1]:
        result <<= 1
        result += ord(ch) - ord('0')
    return result

#generate binary palindromes
bitSequences = ["1"] #start with 1 bit sequences, leading 0 not allowed. These grow to 10 bit sequences

accum = 1 #1 is a bin and dec palindrome, and will not be counted later
print(1,1)


for length in range(2,21): #only used as a counter

    #the 1 bit palindrome is 1, no 2 bit bin and dec palindromes

    '''THAT LAST STATEMENT IS VERY WRONG, 3_10 = 11_2, both palindromes'''
    
    #so start at a length of (X3X) 2

    
    if length % 2 == 1: #when this happens it is time to extend the bit sequences
        bitSequences = [seq + bit for seq in bitSequences for bit in ("0","1")]
        
        for seq in bitSequences: #for each sequence, construct the palindrome of odd length
            binPal = seq[:-1] + seq[::-1]
            dec = binToDec(binPal)
            if dec < 1000000:
                #print(binPal,dec)
                if decimalIsPalindrome(dec):
                    print(binPal,dec)
                    accum += dec
    else:
        for seq in bitSequences:
            binPal = seq + seq[::-1]
            dec = binToDec(binPal)
            if dec < 1000000:
                #print(binPal,dec)
                if decimalIsPalindrome(dec):
                    print(binPal,dec)
                    accum += dec

print(accum)
