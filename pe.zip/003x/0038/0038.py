'''
For a concatenation of products to be 9 digits:

The digit count of Individual products has to fall into
 one of these patterns, with increasing multiplier:

Note that obviously increasing the multiplier by one cannot
increase digit count by two, and cannot decrease it.

1-1-1-1-1-1-1-1-1
1-1-1-1-1-1-1-2
1-1-1-1-1-2-2
1-1-1-2-2-2
1-2-2-2-2
3-3-3
1-1-1-1-2-3
1-1-2-2-3
2-2-2-3
1-2-3-3
2-3-4
4-5


The search space for the largest 1-9 pandigital that is a concatenated product
is (918273645,1000000000) since 918273645 is generatable

The patterns that are likely to give a highest result are those that start with 
(x,x+1) since a base factor starting with digit 9 is required, so multiplying by
just 2 will increase its digit count.

The possible patterns are thus:

1-2-2-2-2
1-2-3-3
2-3-4
4-5

Of these, 1-2-3-3 and 2-3-4 are impossible since no 1 digit number multiplied 
by 3 is 3 digits, and the same for any 2 digit number being 4 digits.

1-2-2-2-2
4-5
remain.

With the 1-2-2-2-2 case, it is absolutely required that the base factor be 
exactly 9 but that merely yields 918273645, an already known result.

A larger concatenation must be in the form 4-5, so simply find the largest 4 
digit number that when doubled, gives a 5 digit number that shares no digits with
it (and no digit 0). Iff it is greater than 9182, that is the answer.
'''

def digitSet(n): 
    ans = set()
    while n > 0:
        ans.add(n % 10)
        n //= 10
    return ans


for i in range(9999,9182,-1): #no lower than 9183
    if len(digitSet(i).union(digitSet(2*i)).union({0})) == 10:
        print("%d%d" % (i,2*i))
    
