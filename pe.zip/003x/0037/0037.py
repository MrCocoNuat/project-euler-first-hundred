'''
probably don't need primes above 6 digits?
'''

MAX_PRIME = 1000000 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    primes.append(numbers[0])
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

print("primes generated")

oneDigitPrimes = [2,3,5,7]

leftTruncPrimes = []
newLeftPrimes = oneDigitPrimes
while newLeftPrimes:
    leftTruncPrimes.extend(newLeftPrimes)
    newLeftPrimes = [int(str(digit) + str(prime)) for digit in range(1,10) for prime in newLeftPrimes if int(str(digit) + str(prime)) in primes]
    
rightTruncPrimes = []
newRightPrimes = oneDigitPrimes
while newRightPrimes:
    rightTruncPrimes.extend(newRightPrimes)
    newRightPrimes = [prime*10 + digit for digit in range(1,10) for prime in newRightPrimes if prime*10 + digit in primes]

accum = 0 - 2 - 3 - 5 - 7 #exclude the one digit times
for p in rightTruncPrimes:
    if p in leftTruncPrimes:
        print(p) #this happens to generate 15 primes, 4 of which are 1 digit and not counted. Enough!
        accum += p

print("sum")
print(accum)
