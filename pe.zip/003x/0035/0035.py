#generate the 4 digit primes

MAX = 1000000 #largest prime desired

numbers = [x for i in range(6,MAX+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    primes.append(numbers[0])
    if numbers[0]**2 > MAX:
        primes, numbers = primes + numbers[1:], []
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

print("primes generated")

def prime(n): #el cheapo binary search
    lo, hi = 0, len(primes)
    while(lo < hi):
        mid = lo + (hi - lo)//2
        if n == primes[mid]:
            return True
        if n < primes[mid]:
            hi = mid
        if n > primes[mid]:
            lo = mid + 1
    return False

    
hits = 0
for p in primes:
    p = str(p)
    rot = p[1:] + p[0]
    result = 1
    while(int(rot) != int(p)):
        if not prime(int(rot)):
            result = 0
        rot = rot[1:] + rot[0]
    hits += result
        
print(hits)
