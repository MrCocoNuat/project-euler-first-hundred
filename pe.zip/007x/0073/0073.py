'''
bruteforce
use totient tricks and PIE to do faster?
'''

import math

accum = -1 #this counts 1/3 which is not included
for d in range(1,12001):
    for n in range(d//3,d//2):
        if math.gcd(n,d) == 1:
            accum += 1

print(accum)
