'''
n/phi(n) = 1/[(1 - 1/p)(1 - 1/p)(...)] for all prime factors p

A minimum n/phi(n) has very few, very large prime factors
'''

MAX_PRIME = 10000 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

print("primes generated")

def phi(n): #not correct for n = 1 but who cares
    #requires a prime table up to n
    primeFacs = []
    nCopy = n
    isPrime = True
    for p in primes:
        if n == 1:
            break
        if n % p == 0:
            isPrime = False
            primeFacs.append(p)
            while n % p == 0:
                n //= p

    for p in primeFacs:
        nCopy = nCopy // p * (p-1)
    if isPrime:
        nCopy -= 1
    return nCopy


for i in range(1,100):
    print(i, phi(i))
