factorials = [1]
for i in range(1,10):
    factorials.append(i*factorials[-1])

def sumDigitFac(n):
    return sum([factorials[int(ch)] for ch in str(n)])

accum = 0
for i in range(10,1000000): #clearly one digits are worthless
    j = i
    chainLength = 0
    seen = []
    while i not in seen:
        seen.append(i)
        i = sumDigitFac(i)
        chainLength += 1
        
    if chainLength == 60:
        print(j, "hit")
        accum += 1
    if j % 1000 == 0: 
        print(j)
print(accum)
        
