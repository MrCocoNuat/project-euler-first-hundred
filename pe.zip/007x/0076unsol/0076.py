'''
Methodology:

Different orderings of terms are still the same sum

sums_>2terms(100) = sums(1)+sums(2)+sums(3)...+sums(50) + (all sums with largest number less than 50)

'''



