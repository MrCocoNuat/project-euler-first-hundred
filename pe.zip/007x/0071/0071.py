'''
Methodology:

blind guessing basically!
''

maxfrac = 0
maxn = 0
maxd = 0

for d in range(1,1000001):
    n = int(maxfrac * d) #iterative guess, often skips loop
    #n = 3*d//7 - 1 #a bit slower, since it more often goes for a loop once
    while(7*n + 7< 3*d): #int arithmetic fast
        n+= 1
    if (n/d > maxfrac):
        maxn = n
        maxd = d
        maxfrac = n/d

print("Found: " + str(maxn) + "/" + str(maxd))
