
#the number of proper reduced fractions that have denominator n is just phi(n)

#since only n up to 1000000 is needed this is easy, if a little time consuming

MAX_PRIME = 1000001 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

print("primes generated")

primeFacs = {1:[]} #stores prime factors
for n in range(2,1000001):
    nCopy = n

    if n % 1000 == 0:
        print(n)
        
    for p in primes:
        if n % p == 0:
            while n % p == 0:
                n //= p
            pf = [p]
            pf.extend(primeFacs[n])
            primeFacs[nCopy] = pf
            break

print("prime factors generated")
        
def phi(n): #not correct for n = 1 but who cares
    #requires a prime table up to n
    pf = primeFacs[n]

    for p in pf:
        n = n // p * (p-1)
    return n

accum = 0
for i in range(2,1000001): #exclude 1/1
    accum += phi(i)
    if i % 1000 == 0:
        print(i) #report count
print(accum)
