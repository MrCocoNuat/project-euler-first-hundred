'''
Primitive pythagorean triples are one-to-one with (m,n) such that:

a = mm - nn, b = 2mn, c = mm + nn
m coprime n, exactly one of m,n even, m>n>0

but a,b are not guaranteed to be ordered. No problem, just swapped

the perimeter will be 2m(m+n) <= 1.5M, so m(m+n) <= 750k

since this problem does not want only primitive solutions:
once a value of perimeter is acquired add all its multiples to the dict

the highest n that has to be tested is before
(n+1)(n+1 + n) = (2nn+3n+1)> 750k, which happens at n=612
because smallest possible m value is n+1
thus only testing to n=611 is good

do a full scan
'''

def coprime(m,n): #euclidean algorithm for gcd, m > n
    while n > 1:
        m, n = n, m%n
    return n == 1

perimeterPossibilities = {} #keys are actually perimeter/2
for n in range(1,612):
    m=n+1
    while m*(m+n) <= 750000:
        if coprime(m,n):
            perimeter = m*(m+n) #actually perimeter/2
            for k in range(1,750000//perimeter + 1):
                perimeterPossibilities[k*perimeter] = perimeterPossibilities.get(k*perimeter,0) + 1
            
        m+=2 #guarantees forever opposite parities

print(list(perimeterPossibilities.values()).count(1))

