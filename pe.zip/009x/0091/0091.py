'''
both coordinates can range from 0 to 50, integers

right angle at P:
slope OP = y1/x1
slope PQ = (y2-y1)/(x2-x1)
OP perp PQ, therefore
y1/x1 = (x1-x2)/(y2-y1)
y1(y2-y1) = x1(x1-x2)

right angle at O:
there are maxCoord^2 of these

additionally to be a triangle,
Neither P or Q can be (0,0) which would also report as true
P and Q cannot be same

counting every possibility of these is not so bad since there are only 51^4 ~= 6M cases, tiny

'''
maxCoord = 50
accum = maxCoord*maxCoord
for x1 in range(0,maxCoord+1):
    for y1 in range(0,maxCoord+1):
        for x2 in range(0,maxCoord+1):
            for y2 in range(0,maxCoord+1):
                    if ((x1 != 0 or y1 != 0) and (x2 != 0 or y2 != 0)): #neither point is equal to O
                        if (x1 != x2 or y1 != y2): #two points are not equal
                            if (y2-y1)*y1 == (x1-x2)*x1: #right angle at a specific point
                                #print("(%d,%d) (%d,%d)" % (x1,y1,x2,y2))
                                accum += 1

print(accum)
