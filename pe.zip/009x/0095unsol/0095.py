'''
smartforce
'''

MAX_PRIME = 1000000 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]
    
print("primes generated")

def primeFactors(n): #returns {p:k} for each prime p and power k
    result = {}
    for factor in primes:
        if n == 1:
            break
        if n % factor == 0:
            while n % factor == 0:
                result[factor] = result.get(factor,0) + 1
                n //= factor

    return result
        

def divisorSum(n): #not prime divisors
    result = [1]
    factors = primeFactors(n)
    for p in factors:
        result = [r * p**k for r in result for k in range(factors[p]+1)]
    return sum(result) - n #don't include n itself


friends = {} #stores n:divisorSum(n) only if 1 < divisorSum(n) <= 1M

for i in range(1,100001):
    j = divisorSum(i)
    print(i,j)
    
chainLength = {} #chain length for each n
currentChain = {} #n : chainIndex
