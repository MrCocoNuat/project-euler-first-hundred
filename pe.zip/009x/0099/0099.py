'''
just do it
'''
import math

fh = open("base_exp.txt","r")

linenum = 0
maxlog = -10**10
maxline = 0
while True:
    line = fh.readline()[:-1] #strip newline
    linenum += 1
    if len(line) == 0: #the end
        break

    components = [int(x) for x in line.split(",")] #base, power
    newlog = components[1] * math.log(components[0])

    if newlog > maxlog:
        maxline = linenum
        maxlog = newlog

print(maxline)
    
