#create a hash table where the hash is the identity function
#the largest first value is 9999999, largest second value is 7*81.
#a table of the ending value for the first 7*81 numbers is enough!


table = [-1 for i in range(0, 7*81 + 1)] #-1 is null, 0 is ends 1, 1 is ends 89
table[1] = 0
table[89] = 1


def squareDigits(n):
    accum = 0
    while n:
        accum += (n%10)**2
        n //= 10
    return accum

def mark(n): #for the first 7*81 numbers
    if table[n] == -1:
        table[n] = mark(squareDigits(n))
    return table[n]
    
for i in range(1, 7*81 + 1):
    mark(i)

hits = 0
for i in range(1,10000000):
    hits += table[squareDigits(i)]
    if (i % 100000 == 0):
        print("up to %d: %d" % (i, hits))

print(hits)
