'''
let digit N represent any digit
let digit X represent either 6 or 9

Let 0 be only on die A
then let 1,4,X are only on die B
then let X is on die A
then let 8 is on die A

3 can be on either die

2 and 5 are on either die

a minimal die set is: {[0,X,8,2,N,N], [1,4,X,3,5,N]}

assuming that these requirements are all,
the number of dice sets, not counting order within a die, is

2*2 for choice of X
2 for position of 2 and 5
2 for position of 3
10*10*10 for choice of N
the answer is not 16000 so this method of counting is not complete
or overcounts

'''
