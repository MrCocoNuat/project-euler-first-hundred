buf = 1
for i in range(0,7830457): #much much faster with efficient muls and squares but it is fast enough
    buf = (buf*2)%10000000000
buf = (buf*28433)%10000000000
print(buf+1)

