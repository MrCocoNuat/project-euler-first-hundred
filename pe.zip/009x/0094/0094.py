'''
every almostequilateral has sides (a,a,a+-1) and has perimeter 3a+-1

the area by Hero's is 
sqrt((3a/2 +- 1/2)(a/2 -+ 1/2)(a/2 +- 1/2)^2)
= (a+-1)/2 * sqrt(3aa/4 -+ a/2 - 1/4) 
= (a+-1)*sqrt(3aa-+2a-1)/4
must be an integer


so (a+-1)*sqrt(3aa-+2a-1) must be divisible by 4
let a = 0mod2, 3aa-+2a-1 is never square, 3mod4
let a = 1mod2, 3aa-+2a-1 might be evensquare


so only ever check a = 1mod2, then whenever 3aa-+2a-1 is square add that perimeter
to the total solution

check perimeters up to 1G, so check odd a up to 333M, which is a lot
'''
import math

print("counter must reach 333M")

accum = 0
for i in range(3,333333334,2): #skip side length 1 since 1,1,2 and 1,1,0 have int area
    if i%10000000 == 1:
        print(i)
    n = 3*i*i+2*i-1
    if math.isqrt(n)**2 == n:
        accum += 3*i-1
        print(i,i,i-1)
    n = 3*i*i-2*i-1
    if math.isqrt(n)**2 == n:
        accum += 3*i+1
        print(i,i,i+1)
    
print("done")
print(accum)
