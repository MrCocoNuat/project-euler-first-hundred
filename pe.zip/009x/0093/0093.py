'''
constructive approach, only four operations permitted, and only integers

with two values there are six possible outputs:
a+b, a-b, b-a, a*b, a/b, b/a
filter for only positive integers
'''

maxConsecutive = 0
maxString = "" #answer

#i > j > k > l
digitLists = [[i,j,k,l] for i in range(3,10) for j in range(2,i) for k in range(1,j) for l in range(0,k)]

assert len(digitLists) == 210 #10choose4

for ls in digitLists:
    i,j,k,l = ls[0],ls[1],ls[2],ls[3]
    I,J,K,L = {i},{j},{k},{l}
    
    IJ = set()
    IK = set()
    IL = set()
    JK = set()
    JL = set()
    KL = set()
    twoCombos = [(IJ,I,J),(IK,I,K),(IL,I,L),(JK,J,K),(JL,J,L),(KL,K,L)]

    '''
    for combo in twoCombos:
        ansSet = combo[0]
        for a in combo[1]:
            for b in combo[2]:
                ansSet.add(a+b)
                if a > b:
                    ansSet.add(a-b)
                else:
                    ansSet.add(b-a)
                if a * b > 0:
                    ansSet.add(a*b)
                    if a % b == 0:
                        ansSet.add(a//b)
                    if b % a == 0:
                        ansSet.add(b//a)
    '''
    #intermediate results CAN be nonpositive and nonintegers!!!
    
    for combo in twoCombos:
        ansSet = combo[0]
        for a in combo[1]:
            for b in combo[2]:
                ansSet.add(a+b)
                ansSet.add(a-b)
                ansSet.add(b-a)
                ansSet.add(a*b)
                if b != 0:
                    ansSet.add(a/b)
                if a != 0:
                    ansSet.add(b/a)

    #replicate this process 3 times
                    
                    
    IJK = set()
    IJL = set()
    IKL = set()
    JKL = set()
    threeCombos = [(IJK, I, JK), (IJK, IJ, K), (IJK, IK, J),
                   (IJL, I, JL), (IJL, IJ, L), (IJL, IL, J),
                   (IKL, I, KL), (IKL, IK, L), (IKL, IL, K),
                   (JKL, J, KL), (JKL, JK, L), (JKL, JL, K)]

    for combo in threeCombos:
        ansSet = combo[0]
        for a in combo[1]:
            for b in combo[2]:
                ansSet.add(a+b)
                ansSet.add(a-b)
                ansSet.add(b-a)
                ansSet.add(a*b)
                if b != 0:
                    ansSet.add(a/b)
                if a != 0:
                    ansSet.add(b/a)


    IJKL = set()
    fourCombos = [(IJKL, I, JKL), (IJKL, J, IKL), (IJKL, K, IJL), (IJKL, L, IJK)]

    for combo in fourCombos:
        ansSet = combo[0]
        for a in combo[1]:
            for b in combo[2]:
                ansSet.add(a+b)
                ansSet.add(a-b)
                ansSet.add(b-a)
                ansSet.add(a*b)
                if b != 0:
                    ansSet.add(a/b)
                if a != 0:
                    ansSet.add(b/a)

                    
    fourList = [n for n in IJKL if int(n) == n and n > 0] #append 0 for easy checking
    fourList.insert(0,0)
    
    nTest = 0 #that way this loop always enters
    while nTest in fourList:
        nTest += 1

    if nTest > maxConsecutive:
        maxConsecutive = nTest
        maxString = str(l) + str(k) + str(j) + str(i)
        print(maxString, nTest) #nTest is the first number not possible to make

print(maxString)
