for i in range(0,1000):
    for j in range(i,(1001+i)//2):
        if (i**2 + j**2 == (1000 - i - j)**2):
            print(str(i) + " " + str(j) + " " + str(1000-i-j) + " " + str(i*j*(1000-i-j)))
            break
        
