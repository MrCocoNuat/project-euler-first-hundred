#include <stdio.h>
int gcd(int a, int b);

int accum = 1;
int mod;

int main(void){
  for(int factor = 20; factor; factor--) if (mod = accum % factor) accum *= factor/gcd(mod,factor);
  printf("%d\n",accum);
}

int gcd(int a, int b){
  int c;
  if (!(c = a % b)) return b;
  return gcd(b,c);
}
