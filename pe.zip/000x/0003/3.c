#include <stdio.h>
#include <math.h>

int main(void){
  long target = 600851475143, query = 1; 
  while((target /= query) > 1) for(query = 3; target % query; query += 2);
  printf("%ld\n", query);
}
