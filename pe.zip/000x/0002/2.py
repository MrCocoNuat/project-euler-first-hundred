accum = 0

f1=1
f2=2
f3=3

while(f2 <= 4000000):
    accum += f2
    f1 = f2 + f3
    f2 = f1 + f3
    f3 = f1 + f2


print(accum)
