#include <stdio.h>

int mula, mulb, maxb = 0;
int prod, result;
int isnotpal(int p);


int main(void){
  for(mula = 999; mula > maxb; mula--){
    for(mulb = mula; mulb > maxb; mulb--){
      if (!isnotpal(prod = mula * mulb) && prod > result){
	result = prod;
	maxb = mulb;
	break;
      }
    }
  }
  printf("%d\n",result);
}

int isnotpal(int p){
  return (p / 1000) - 100*(p % 10) - 10*(p / 10 % 10) - (p / 100 % 10);
}
