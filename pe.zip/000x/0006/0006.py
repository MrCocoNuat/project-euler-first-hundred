accum1 = 0
accum2 = 0

for i in range(1,101):
    accum1 += i
    accum2 += i*i

print(accum1**2 - accum2)


#(1+2+3+4+5..+n)^2 = (n)^2(n+1)^2/4
#(1^2+2^2+...+n^2) = (n)(n+1)(2n+1)/6
#difference = n(n+1)(3n^2-n-2)/12 = n(n+1)(n-1)(3n+2)/12
