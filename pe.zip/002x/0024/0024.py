#there are 10! permutations in total, 9! for each starting digit

#1M/9! = 2 % 274240
#the first number is the (2+1)rd smallest (2),
#then look for the 274240th permutation of the 9 remaining digits

#274240/8! = 
#and so on, up to the last digit

from math import prod

digits = [0,1,2,3,4,5,6,7,8,9] #these should be sorted
counter = 1000000 #which permutation to get

counter -= 1 #people usually start counting at 1
def factorial(n):
    return prod([i for i in range(1,n+1)])

permutation = '' #the answer
while len(digits) > 0:
    nextDigit = counter // factorial(len(digits) - 1)
    counter %= factorial(len(digits) - 1)
    permutation += str(digits.pop(nextDigit))

print(permutation)
