fh = open("p022_names.txt","r")

names = fh.readline().replace("\"","").split(",")
names.sort() #nice, built in alphabetical sort

def nameSum(name):
    score = 0
    for ch in name:
        score += ord(ch) - ord("A") + 1
    return score

accum = 0
for i in range(len(names)):
    accum += (i+1)*nameSum(names[i])
    if names[i] == "COLIN":
        assert 938 == i+1 #given
print(accum)
