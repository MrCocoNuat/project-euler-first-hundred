import math

def properFactorSum(n): #not efficient but eh
    factors = [1]
    for i in range(2,math.isqrt(n) + 1):
        if (n % i == 0):
            factors.append(i)
            if (i != n//i):
                factors.append(n//i)
    return sum(factors)

sums = [properFactorSum(i) for i in range(0,30001)]
#the highest proper factor sum of a number less than 10001 is less than 30001 apparently 

sums[0] = 0 #for index matching

accum = 0 #number of amicable numbers
for i in range(1,10001):
    if i != sums[i] and i == sums[sums[i]]:
        accum += i

print(accum)
