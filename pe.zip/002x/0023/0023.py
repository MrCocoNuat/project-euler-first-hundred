import math

def properFactorSum(n): #not efficient but eh
    factors = [1]
    for i in range(2,math.isqrt(n) + 1):
        if (n % i == 0):
            factors.append(i)
            if (i != n//i):
                factors.append(n//i)
    return sum(factors)

def abundants(maxN):
    abundant = []
    for i in range(1,maxN):
        if properFactorSum(i) > i:
            abundant.append(i)
    return abundant

abundantNums = abundants(28123)
allNums = [i for i in range(0,28123+1)]

abundantSums = set()
for i in range(len(abundantNums)):
    for j in range(i,len(abundantNums)):
        if abundantNums[i] + abundantNums[j] > 28123:
            break
        allNums[abundantNums[i] + abundantNums[j]] = 0

#ans = sum([i for i in range(1,28123+1)]) - sum(abundantSums)
ans = sum(allNums)

print(ans)
