#count 1, then skip 1, skip 1, skip 1, skip 1, skip 3, skip 3, skip 3, skip 3, skip 5, ..., skip 5, ..., ..., ..., skip 999, skip 999, skip 999, skip 999

#therefore, add 1, add 3, add 5, add 7, add 9, (skip 1 in between)
#           add 13, add 17, add 21, add 25     (skip 3 in between)

accum = 1 #just start with 1
current = 1 #just start with 1
for skip in range(2,1001,2):
    current += skip
    accum += current
    current += skip
    accum += current
    current += skip
    accum += current
    current += skip
    accum += current

print(accum)
