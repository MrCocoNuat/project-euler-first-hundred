MAX = 10000 #largest prime desired

numbers = [x for i in range(6,MAX+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    primes.append(numbers[0])
    if numbers[0]**2 > MAX:
        primes, numbers = primes + numbers, []
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

def search(n, l):
    lo, hi = 0, len(l)
    while(lo < hi):
        mid = lo + (hi - lo)//2
        m = l[mid]
        if n < m:
            hi = mid
        elif n > m:
            lo = mid + 1
        else:
            return True
    return False

maxN = 0
maxAB = [0,0]
for a in range(-999,1000,2): #no point testing (a,b) when both even
    for b in range(-999,1000,2-a%2):
        n = 0
        while search((n+a)*n+b, primes):
            n += 1
        if n > maxN:
            maxN = n
            maxAB = [a,b]
print(maxAB, maxAB[0]*maxAB[1])
print(maxN)

#ans is [-61,971]
