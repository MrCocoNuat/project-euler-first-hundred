#the cycle period of a recurring decimal 1/n is the smallest i for which
#10^i - 1 is divisible by m = n stripped of all factors of the number base (2 and 5)

#this is also how to find fractions equal to some repeating decimal
'''

0.016(abcdef) * 1000 =  16.(abcdef) [eliminate pre-repeating section]
0.(abcdef) * 1000000 = abcdef.(abcdef)
0.(abcdef) * 999999 = abcdef
0.(abcdef) = abcdef/999999
0.016(abcdef) = (16 + abcdef/999999)/1000
'''

longestDenom = 0
longestPeriod = 0
for n in range(1,1000):
    m = n
    while m % 5 == 0:
        m //= 5
    while m % 2 == 0:
        m //= 2
    if m == 1:
        continue #skip, terminating
        
    period = 1
    nines = 9
    while nines % m != 0:
        period += 1
        nines = nines * 10 + 9

    if period > longestPeriod:
        longestPeriod = period
        longestDenom = n

print(longestDenom, "with period", longestPeriod)
