counter = 2 #index of the second number in the list

fib = [1,1] 
while fib[1] < 10**999:
    fib = [fib[1], fib[0] + fib[1]]
    counter += 1

print(counter)

#obviously faster by calculating with an explicit formula for fib numbers,
#but not by enough to really matter...
