#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int main(void){
  
  FILE *f1 = fopen("cipher.txt","r");
  char c = 0;
  int count = 1;
  
  while((c = getc(f1)) != EOF){
    if (c == ',') count++;
  }
    
  char *cipher = (char*)malloc(count+1);
  char *plain = (char*)malloc(count+1);
  
  int index = 0;
  FILE *f2 = fopen("cipher.txt","r");
  while((c = getc(f2)) != EOF){
    if (c == ','){
      index++;
    }
    else if (isdigit(c)){
      cipher[index] = cipher[index]*10 + (c - '0');
    }
  }
  
  char key[3];

  printf("begin decrypt\n");
  
  for(key[0] = 'a'; key[0] <= 'z'; key[0]++){

    for(key[1] = 'a'; key[1] <= 'z'; key[1]++){

      for(key[2] = 'a'; key[2] <= 'z'; key[2]++){
	int index;
	for(index = 0; index < count; index++){
	  char plainchar = cipher[index] ^ key[index % 3];
	  //printf("%d\n",plainchar);
	  plain[index] = plainchar;
	  if (!isalnum(plainchar) && !isspace(plainchar) && !ispunct(plainchar)){ //very unlikely
	    break;
	  }
	}
	if (index == count){ //good key
	    printf("key %c%c%c: ",key[0],key[1],key[2]);
	    for(int i = 0; i < 70; i++){ //sample
	      printf("%c",plain[i]);
	    }
	    printf("\n");
	}
      }
    }
  }
  //the key is exp, decoded by eye from the remaining 300 or so keys.
  //analysis by counting alnum and space chars would be better.

  char correctkey[] = {'e','x','p'};

  int accum = 0;
  for(index = 0; index < count; index++){
    char plainchar = cipher[index] ^ correctkey[index % 3];
    accum += plainchar;
    putchar(plainchar);
  }

  printf("\n Sum: %d\n",accum);
}
