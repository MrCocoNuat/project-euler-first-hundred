'''
find smallest prime containing digit X such that replacing the digit X with seven other digits gives primes

digit spacing is generalized

to be smallest prime in family X has to be in {0,1,2}

divisibility by 3 is important,

if the number of digits X is not divisible by 3,
then it is impossible for a 8 prime family to exist, since their residues 
oduli three woule be, for example
 X = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
%3 = 1, 0, 2, 1, 0, 2, 1, 0, 2, 1
no less than 3 0s will appear

therefore such a prime family must have 3, 6, 9, ... digits X
start searching for primes with 3 of the same digit in {0,1,2}
'''

MAX_PRIME = 1000000 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

def isCandidate(p): #has at least 3 of the same digit under 3
    digitDict = {}
    for ch in str(p):
        digitDict[ch] = digitDict.get(ch,0) + 1
    return digitDict.get("0",0) >= 3 or digitDict.get("1",0) >= 3 or digitDict.get("2",0) >= 3

candidatePrimes = [p for p in primes if isCandidate(p)]

def familyList(p): #returns a list of families that this prime belongs to
    p = [ch for ch in str(p)]
    families = []
    digitLocations = {"0":[],"1":[],"2":[]}
    for i in range(len(p)):
        ch = p[i]
        if ch == "0" or ch == "1" or ch == "2":
            digitLocations[ch].append(i)
    for beforeDigit in digitLocations:
        #NOTE, if for example 4 digit 2s exist in the number
        #this will change all of them and lump the results into 1 family,
        #instead of creating 4 families where just 3 are changed in each
        #primes with 4 same digits under 3 are rare enough that this probably is ok
        if len(digitLocations[beforeDigit]) >= 3:
            family = []
            for digit in range(0,10):
                if digit == 0 and digitLocations[beforeDigit][0] == 0:
                    continue #no leading 0
                newP = list(p)
                for loc in digitLocations[beforeDigit]:
                    newP[loc] = str(digit)
                family.append(int("".join(newP)))
            families.append(family)
    return families

def familySuccess(p):
    for family in familyList(p):
        successes = 0
        for pf in family:
            if pf in primes:
                successes += 1
    return successes
            

print("members of 8-families:")
for p in candidatePrimes:
    if familySuccess(p) >= 8:
        print(p)
        break #only one answer needed
