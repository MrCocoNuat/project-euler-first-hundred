'''
bruteforce
'''

maxDigitSum = 0
maxA, maxB = 0, 0

for a in range(1,100):
    for b in range(1,100):
        digitSum = sum([int(ch) for ch in str(a**b)])
        if digitSum > maxDigitSum:
            maxDigitSum = digitSum
            maxA, maxB = a, b

print(maxDigitSum)
