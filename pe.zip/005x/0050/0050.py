'''
find the prime under 1M that can be written as the sum of the most consecutive primes. The number of consecutive primes should definitely be greater than 21.
'''

#it is given that a chain of 21 primes sums to 953, the record for sum under 1000
#then the new chain must have at least 22 primes, which means the smallest can be at most 1M/22 for the sum to be < 1M
#it is reasonable then that the largest can't be greater than 1M/20 or so

maxCount = 21 #given record length for sum under 1000
maxCountPrime = 953

MAX_PRIME = 1000000 #largest prime desired
MAX_SUM = 1000000 #largest sum allowed

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

print("primes generated")
print(primes[:50])


for start in range(len(primes)):
    print("starting prime:", primes[start])
    primeSum = primes[start]
    count = 1
    
    #count the next maxCount primes immediately, since a record chain has to be longer than the old record
    for i in range(maxCount-1):
        primeSum += primes[start + count]
        count += 1
        
    if primeSum >= MAX_SUM: #if any chain that would beat the record has too high of a sum, search is done
        break
    
    while primeSum < MAX_SUM: #sum must be < 1M
        if primeSum in primes:
            if count > maxCount:
                maxCount = count
                maxCountPrime = primeSum
                print("new record chain:", primeSum, "count:", count)
                
        primeSum += primes[start + count]
        count+= 1
        


print("prime that is longest sum:")
print(maxCountPrime)
