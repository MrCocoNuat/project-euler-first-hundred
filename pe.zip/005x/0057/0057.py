'''
bruteforce
'''

#no need to ever reduce fractions, the num/den will always be coprime

#no need to create new fractions, keep them in place with lists

accum = 0
expansion = [3,2] #don't need to count this, not satisfying

def add1():
    global expansion
    expansion = [expansion[0] + expansion[1], expansion[1]]

def recip():
    global expansion
    expansion = [expansion[1], expansion[0]]
    
for i in range(999):
    add1()
    recip()
    add1()
    if len(str(expansion[0])) > len(str(expansion[1])):
        accum += 1

print(accum)
