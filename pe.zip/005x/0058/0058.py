'''
the elements in diagonals are

n^2 (composite)
n^2 - n + 1
n^2 - 2n + 2
n^2 - 3n + 3
for all odd n > 1
'''

MAX_PRIME = 100000 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

def isPrime(n):
    for p in primes:
        if p*p > n:
            return True
        if n % p == 0:
            return False
    
primecount = 0
total = 1 #the center 1 counts
n = 1

starting = True #otherwise loop never starts

while (starting or total <= 10*primecount):
    starting = False
    n += 2
    total += 4
    if isPrime(n*n - n + 1):
        primecount += 1
    if isPrime(n*n - 2*n + 2):
        primecount += 1
    if isPrime(n*n - 3*n + 3):
        primecount += 1
        
        
print(n)
