#A bit cheaty, but who at this point does not know of the fun cyclic nature of n/7?

print(1/7)
