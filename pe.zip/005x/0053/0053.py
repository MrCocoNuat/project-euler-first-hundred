'''
let m = n/2
if r_2 is closer to m than r_1 then c(n,r_2) > c(n,r_1)
'''

import time

start = time.time_ns()

trials = 1000
for i in range(1,trials + 1): #repeat many times for timing

    
    count = 0;
    for n in range(23,101):
        r = 0
        choose = 1 #r starts from 0, c(n,0) = 1
        while(choose <= 1000000): #increment r until exceeding 1
            r+= 1
            choose = choose * (n-r+1) // r #iterative combination
            
            #c(n,r) is now above 1M, count the rest of the cases
        count += (n-2*r+1)


        
print(str((time.time_ns() - start)//trials) + " ns for one computation")
#80us for one computation
    
print(count)

