'''
Ca-c-c--c---c---ca--c-c----c--ca--... (retires)

Define each card as a list of 2, [value, suit]
with the value equal to the card number, or in the case of a face card,
J = 11, Q = 12, K = 13, A = 14

Hands can be compared based on their score

Royal Flush = 140Qa implicitly
Straight Flush = 10Qa * high card
Four of a Kind = 100T * value of four of a kind
Full House = 1T * high card of full house
Flush = 10G * high card
Straight = 100M * high card
Three of a Kind = 1M * value of three of a kind
Two Pair = 10k * higher pair
One Pair = 100 * value of pair
High Card = 1 * high card

in any straight low card = high card - 4, naturally
'''

def value(tup): #utility
    return tup[0] 

fh = open("/home/person/segfault/peuler/005x/0054/p054_poker2.txt")

dictValue = {"2":2, "3":3, "4":4, "5":5, "6":6, "7":7, "8":8, "9":9, "T":10, "J":11, "Q":12, "K":13, "A":14}
dictSuit = {"D":1, "C":2, "H":3, "S":4}
#suit values are arbitrary since the problem guarantees that matches won't come down to suits


rawLine = fh.readline()

player1Wins = 0 #count
gamesPlayed = 0 #count

threeCount = 0
noCount = 0
houseCount = 0

while rawLine != "":
    line = rawLine[:-1].split(" ")
    for position in range(len(line)):
        line[position] = (dictValue[line[position][0]],dictSuit[line[position][1]])

    hand1 = sorted(line[:5], key=value)
    hand2 = sorted(line[5:], key=value)

    hands = [None, hand1, hand2] #index match
    scores = [None, 0, 0]

    print()
    print(rawLine[:-1])
    
    for number in (1,2):
        hand = hands[number]
        
        FLUSH = False
        if hand[0][1] == hand[1][1] == hand[2][1] == hand[3][1] == hand[4][1]:
            FLUSH = True

        STRAIGHT = False
        if (hand[1][0] - hand[0][0] == 1
            and hand[2][0] - hand[1][0] == 1
            and hand[3][0] - hand[2][0] == 1
            and hand[4][0] - hand[3][0] == 1):
            if FLUSH: #is a straight/royal flush
                scores[number] = 10000000000000000 * hand[4][0]
                print("straight flush")
                continue
            STRAIGHT = True

        valueHistogram = [0 for i in range(0,15)]
        for card in hand:
            valueHistogram[card[0]] += 1

        if 4 in valueHistogram: #is a four of a kind
            scores[number] = 100000000000000
            scores[number] *= valueHistogram.index(4) #value of four of a kind
            print("four of a kind")
            continue

        if 3 in valueHistogram and 2 in valueHistogram: #is a full house
            scores[number] = 1000000000000
            scores[number] *= valueHistogram.index(3) #value of full house is the value of triple
            print("full house")
            houseCount += 1
            continue

        if FLUSH: #is a flush
            scores[number] = 10000000000 * hand[4][0]
            print("flush")
            continue

        if STRAIGHT: #is a straight
            scores[number] = 100000000 * hand[4][0]
            print("straight")
            continue

        if 3 in valueHistogram: #is a three of a kind
            scores[number] = 1000000
            scores[number] = valueHistogram.index(3)
            print("three of a kind")
            threeCount += 1
            continue
        
        if valueHistogram.count(2) == 2: #is a two pair
            scores[number] = 10000
            scores[number] *= 14 - valueHistogram[::-1].index(2)
            print("two pair")
            continue
            
        if 2 in valueHistogram: #is a one pair
            scores[number] = 100
            scores[number] *= valueHistogram.index(2)
            print("one pair")
            continue
            
        scores[number] = hand[4][0] #is none of these
        print("high card")
        noCount += 1

    gamesPlayed += 1
    
    if scores[1] > scores[2]:
        player1Wins += 1
        print("Player 1 wins", player1Wins,"/",gamesPlayed)
    elif scores[1] == scores[2]:
        hand1Total = sum([hand1[i][0]*(10**i) for i in range(0,5)])
        hand2Total = sum([hand2[i][0]*(10**i) for i in range(0,5)])
        if hand1Total > hand2Total:
            player1Wins += 1
            print("Player 1 wins (tiebreak)", player1Wins,"/",gamesPlayed)
    else:
        print("Player 2 wins")


    rawLine = fh.readline()


print(player1Wins)

print(threeCount/gamesPlayed/2)
print(noCount/gamesPlayed/2)
print(houseCount/gamesPlayed/2)
