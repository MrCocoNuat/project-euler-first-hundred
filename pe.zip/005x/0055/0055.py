'''
bruteforce
'''
accum = 0
for n in range(10000):
    reverse = int(str(n)[::-1])
    isLychrel = True
    for i in range(50):
        n = reverse + n
        reverse = int(str(n)[::-1])
        if n == reverse:
            isLychrel = False
            break
    if isLychrel:
        accum += 1

print(accum)
