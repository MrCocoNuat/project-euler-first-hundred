'''
Methodology:

again, dijkstra it, multiple times! (that's it). Again.
'''

f = open("p082_matrix.txt","r")
matrix = [[int(q) for q in l[:-1].split(",")] for l in f.readlines()]
sums = [[10**10 for q in matrix[0]] for l in matrix] #good enough for infinity

#Traversing the matrix in the direction perpendicular to the subarrays is not optimal but whatever

#assume matrix is square
dim = len(matrix)-1 #max index, not dimensions :( ...

for i in range(0,dim+1):
    sums[i][0] = matrix[i][0] #initialization


sums2 = [] #keep doing this until sums stops changing

while(sums != sums2):
    print("executing loop")
    sums2 = [[q for q in l] for l in sums] #shallow copy!
    for i in range(1,dim+1): #i is the horizontal index
        #the loop will start from the left and work right
        for j in range(0,dim+1): #the vertical component. 
            sums[j][i] = matrix[j][i] + min(
                [sums[j-1][i] if j > 0 else 10**10, #good enough for infinity
                 sums[j+1][i] if j < dim else 10**10,
                 sums[j][i-1] if i > 0 else 10**10]) #cant come from right


candidates = [sums[i][dim] for i in range(0,dim+1)]
print(min(candidates))

