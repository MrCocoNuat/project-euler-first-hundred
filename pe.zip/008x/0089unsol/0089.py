dictRoman = {"I":1, "V":5, "X":10, "L":50, "C":100, "D":500, "M":1000}

def deRoman(numeral): #assumes a valid Roman numeral
    if len(numeral) == 1:
        return dictRoman[numeral]

    number = 0
    prev = dictRoman[numeral[0]]
    for char in numeral[1:]:
        current = dictRoman[char]
        if current > prev:
            number -= prev #subtractive
        else:
            number += prev #additive
        prev = current

    number += dictRoman[numeral[-1]]
    return number



listDigit = [0, 1, 2, 3, 2, 1, 2, 3, 4, 2] #eg digit 8 requires 4 chars, like VIII
def numRoman(i): #how many chars needed? many Ms, then for the other 3 places a variable amount
    return (i//1000 + listDigit[i//100 % 10] + listDigit[i//10 % 10] + listDigit[i % 10]) #assumes a <= 4 digit number





text = open("roman.txt") #edit the file so that it ends in a line containing only a newline, like it should!

accum = 0
line = " "
while (True): #end on a line that is just a newline
    line = text.readline()[:-1] #strip newline
    if (len(line) < 1):
        break
    print("%s = %d" % (line, deRoman(line)))
    accum += len(line) - numRoman(deRoman(line))
    print("save %d chars" % (len(line) - numRoman(deRoman(line))))

print(accum)
