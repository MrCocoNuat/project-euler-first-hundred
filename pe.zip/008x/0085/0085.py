'''
Methodology:

A m*n grid contains (m-a+1)(n-b+1) a*b rectangles

Let r(m,n) be the number of rectangles in an mxn grid
The following recurrence relation defines r
r(m,n+1) = r(m,n) + (n+1)m(m+1)/2 
r(m+1,n) = r(m,n) + (m+1)n(n+1)/2
r(1,1) = 1

If one dimension j is incremented and the other, k, is not,
Each new rectangle must contain some of the new strip 1*k of squares
There are k(k+1)/2 of such rectangles heights', and each can have a width
from 1 to j+1

Test case:
r(2,1) = 1 + 2*1*2/2 = 3
r(3,1) = 3 + 3*1*2/2 = 6
r(3,2) = 6 + 2*3*4/2 = 18 agreeing with the given

Finding m*n such that r(m,n) is closest to 2M is stairstep-able

First, climb to 2M with r(1,n) = n(n+1)/2
Then decrease n when >2M, increase m when <2M. Never =2M
Terminate when n < m as the grid is symmetrical across n = m



**The explicit formula for r(m,n) is just m(m+1)n(n+1)/4, from the choices of two vertical lines from m+1 and two horizontal lines n+1 that bound the rectangle.
It is just a little harder to set up steps for a nonrecursive formula, though
'''

target = 2000000

m = 1
n = 0
r = 0
while(r < target):
    n+= 1
    r = n*(n+1)/2

#now over

closem = m
closen = n
closer = r
while(n >= m):
    if (abs(target-closer) > abs(target-r)):
        closem = m
        closen = n
        closer = r
    if (r > target):
        n-= 1
        r-= (n+1)*m*(m+1)/2
    else:
        r+= (m+1)*n*(n+1)/2
        m+= 1

print("%d * %d = %d gives %d rectangles" % (closem, closen, closem*closen, closer))
 
