'''
Methodology:

brute force lmao
'''
import math    

target = 50000000

MAX_PRIME = math.isqrt(target) #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]
    
squares = [p**2 for p in primes]
cubes = [p**3 for p in primes if p**3 < target]
hypers = [p**4 for p in primes if p**4 < target]

#print(len(hypers) * len(cubes) * len(squares)) #just 1.5M

hits = set()
for s in squares:
    for c in cubes:
        for h in hypers:
            if s+c+h < target:
                hits.add(s+c+h)

print(len(hits))
