'''
Methodology:

again, dijkstra it, multiple times! (that's it)
'''

f = open("p083_matrix.txt","r")
matrix = [[int(q) for q in l[:-1].split(",")] for l in f.readlines()]
sums = [[10**10 for q in matrix[0]] for l in matrix] #good enough for infinity
sums[0][0] = matrix[0][0] #initialization

#assume matrix is square
dim = len(matrix)-1 #max index

#for an easier time coding, let the problem be reformulated as the smallest
#path sum from the bottom right to top left, moving only left or up

sums2 = [] #keep doing this until the sums table is not changing anymore, then done!
while(sums != sums2):
    sums2 = [[q for q in l] for l in sums] #shallow copy!
    for i in range(1,dim*2+1): #i is the sum of the indices (coordinates)
        #the loop will start from the top left and work backwards to bottom right 
        for j in range(max([0,i-dim]),min([i,dim])+1): #the vertical component. 
            sums[j][i-j] = matrix[j][i-j] + min(
                [sums[j-1][i-j] if j > 0 else 10**10, #good enough for infinity
                 sums[j][i-j-1] if i-j > 0 else 10**10,
                 sums[j+1][i-j] if j < dim else 10**10,
                 sums[j][i-j+1] if i-j < dim else 10**10]) 

print(sums[dim][dim])

