'''
Methodology:

again, dijkstra it!
'''

f = open("p081_matrix.txt","r")
matrix = [[int(q) for q in l[:-1].split(",")] for l in f.readlines()]

#assume matrix is square
dim = len(matrix)-1 #max index

#for an easier time coding, let the problem be reformulated as the smallest
#path sum from the bottom right to top left, moving only left or up

for i in range(1,dim*2+1): #i is the sum of the indices (coordinates)
    #the loop will start from the top left and work backwards to bottom right 
    for j in range(max([0,i-dim]),min([i,dim])+1): #the vertical component. 
        matrix[j][i-j] = matrix[j][i-j] + min(
            [matrix[j-1][i-j] if j > 0 else 10**10, #good enough for infinity
             matrix[j][i-j-1] if i-j > 0 else 10**10]) 

print(matrix[dim][dim])

