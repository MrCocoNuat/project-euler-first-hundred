'''
For a a*b*c cuboid, the net reveals three possible shortest surface diagonals d:

d^2 is in {a^2+(b+c)^2, b^2+(c+a)^2, c^2+(a+b)^2}. 
All of these three are just a^2 + b^2 + c^2 + 2xy, where {x,y} in {a,b,c}. 
Thus the shortest d^2 is the one where x and y are the smallest dimensions.

Create all a*b*c cuboids, with the condition that a<=b<=c for uniqueness. 
This means that the shortest d^2 is also c^2 + (a+b)^2. 
If the square root is an integer, that is a hit.

Since the smallest maximal dimension with 1M hits is needed, count hits by the largest dimension, or c.

Small optimization: square numbers are never 4Z+2 or 4Z+3, only 4Z+0 and 4Z+1.
If both c and a+b are odd then d^2 = 4Z+2 is not a square; skip those 
At least this speeds up by up to 25%?
'''

import math

hits = 0
target = 1000000 #a target of 2060 requires c = 100, and 2061 requires 102

c = 0

while (hits < target):
    print(hits)
    c += 1
    
    for b in range(1,c+1):
        if c % 2 == 1:
            arange = range(2-b%2,b+1,2)
        else:
            arange = range(1,b+1)
        for a in arange:
            d2 = a*a + b*b + c*c + 2*a*b
            if d2 - math.isqrt(d2)**2 == 0: 
                hits += 1
                

print(c)
