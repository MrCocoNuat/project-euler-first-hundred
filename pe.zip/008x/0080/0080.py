'''
find the first 100 digits of the irrational sqroots of the first 100 integers
THE WHOLE NUMBER DIGIT COUNTS AS 1/100


if not using arbitrary precision decimals, just use big integers
multiply everything by 10^100 for integer computation
better, multiply by 10^105 for five buffer digits, NO ROUNDING
(one would be enough but why not five, or fifty?)
and use iterative approach methods (Newton's works nicely for simple case)
'''

import math

def sumDigits(n): #sums only the first 100 digits
    return sum([int(ch) for ch in str(n)[:100]])

accum = 0
squares = [n*n for n in range(1,11)]
for i in range(1,101):
    if i in squares: #only count irrational roots
        continue

    root = int(math.sqrt(i * 10**210))
    #this is a good guess but limited precision screws it up

    #d/dx x^2 = 2x, so increasing the root by 1 should increase the square by
    #2*x where x is the value of the root
    
    #print(root*root, "\ndeviation =", float(i*10**210 - root*root))
    
    for x in range(1,4): #3 Newton's iterations. Since d/dx at the target point is quite large, the number of correct digits would approximately double every iteration, and the original guess comes with about 16 correct digits, being derived from a float
        root += (i*10**210 - root*root)//root//2
        
    #print(root*root, "\ndeviation =", float(i*10**210 - root*root))
    #print(i, str(root)[:100], sumDigits(root))
    
    accum += sumDigits(root)

    
print(accum)
