'''
A triangle number is n(n-1)/2

Conveniently n and n-1 are coprime
store the number as a prime factorization
stopping once the sum is >500.

To find the number of divisors of a number, just continually divide it by a prime until the lookup table of primefacs  already has an entry for it. ez
'''

TARGET = 500 #how many divisors wanted

MAX = 100000 #largest prime desired

numbers = [x for i in range(6,MAX+2,6) for x in (i-1,i+1)]
primes = [2,3] #using a wheel of 6 for simple speedups

while numbers:
    primes.append(numbers[0])
    if numbers[0]**2 > MAX:
        primes, numbers = primes + numbers, []
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]
    
#print(primes)

primeFacs = [[],[]] #for 0, 1
#store these indexmatched like: 0,1,1,3,2,5,3,7,4,9,5,11, ... n, 2n+1,
#a little more space, but then finding primefacs of triangle numbers is ez

#dont store all of these!!

def divisors(factorization): #number of divisors
    accum = 1
    for power in factorization:
        accum *= power + 1
    return accum

def mul(fac1, fac2): #unequal lengths ok
    if (len(fac1) < len(fac2)): #switch
        return mul(fac2, fac1)
    prod = [fac1[i] + fac2[i] for i in range(0,len(fac2))]
    return prod + fac1[len(fac2):len(fac1)]
    
    
triangleFac = [] #the first one, 1, when this is large enough the search stops

oldFac = []
while divisors(triangleFac) <= TARGET:
    
    nextNumber = len(primeFacs) // (2 - len(primeFacs) % 2)
    newFac = []
    for p in primes:
        power = 0
        while nextNumber % p == 0:
            power += 1
            nextNumber //= p
        newFac.append(power)
        if nextNumber == 1:
            break


    primeFacs.append(newFac)

    triangleFac = mul(newFac, oldFac)
    oldFac = newFac

accum = 1
for i in range(len(triangleFac)):
    accum *= primes[i] ** triangleFac[i]
print(accum)
