'''
of course these digit names could be random with the right length, but this
makes it easy to check work
'''

#non-american short form names
def numbername(n, power1000 = 0):
    ones = ['','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen']
    tens = ['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'] 
    thousandPower = ['thousand','million', 'billion', 'trillion', 'quadrillion', 'quintillion', 'sextillion', 'septillion', 'octillion', 'nonillion', 'decillion'] #that's probably enough, you don't need 10^3000

    word = ''
    if n == 0:
        return word
    if n >= 1000:
        return numbername(n//1000, power1000 + 1) + thousandPower[power1000] + numbername(n%1000)
    elif n >= 100:
        if n % 100 == 0:
            word = ones[n//100] + 'hundred'
        else:
            word = ones[n//100] + 'hundredand'
    if n%100 <= 19:
        word += ones[n%100]
    elif n%100 <= 99:
        word += tens[n%100//10] + ones[n%10]

    return word

    
accum = 0
for i in range(1,1001):
    word = numbername(i)
    print(word, len(word))
    accum += len(word)

print(accum, "characters")
