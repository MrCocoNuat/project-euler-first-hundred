#include <stdio.h>

int main(void){
  
  int longest = 0;
  int maxLength = 0;
  int length = 0;
  
  for(long i = 1; i < 1000000; length = 0, i++){
    for(long j = i; j > 1; length++, j = (j % 2 == 0)? j/2 : 3*j+1);
    if (length > maxLength){
      longest = i;
      maxLength = length;
      //printf("found: %7d length %d\n",i,length);
    }
  }

  printf("%d\n",longest);
}
