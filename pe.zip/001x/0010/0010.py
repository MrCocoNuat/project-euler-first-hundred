primes = [2]
index = 0

query = 3
while query < 2000000:
    prime = True
    for p in primes:
        if (query % p == 0):
            prime = False
            break
        if (p*p > query):
            break
    if prime:
        primes.append(query)
        index += 1
    query += 2

accum = 0
for p in primes:
    accum += p

print(accum)
