day = 1 #Mon = 1, Sat = 6, Sun = 0
#1900/1/1 is a Monday
accum = 0 #count of sundays on the first of the month

for year in range(1900,2001):
    monthTable = [0,31,28,31,30,31,30,31,31,30,31,30,31] #days in a month
    if (year % 4 == 0) and (year % 100 != 0 or year % 400 == 0):
        monthTable[2] = 29

    for month in range(1,13):
            if day == 0 and year > 1900:
                #only count special sundays in years 1901 and on
                accum += 1
                print("Sunday %d/%d/1" % (year,month+1))
            day = (day + monthTable[month]) % 7

print(accum)
