#well this is easy

print(sum([int(ch) for ch in str(2**1000)]))
