print(str(sum([int(s) for s in open("ADDME.txt","r").readlines()]))[:10]) #one liners are the best liners
