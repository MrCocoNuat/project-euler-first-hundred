'''
manual bruteforce

exclude base 0

for base = 1 to 3, only satisfy n=1. Count + 3
for base = 4, only satisfy n=1,2. Count + 2
for base = 5, only satisfy n=1,2,3. Count + 3
for base = 6, only satisfy n=1,2,3,4. Count + 4
for base = 7, only satisfy n=1,2,3,4,5,6. Count + 6
for base = 8, only satisfy n=1,2,3,...,10. Count + 10
for base = 9, only satisfy n=1,2,3,...,21. Count + 21

essentially, find int(log_i/10 (0.1)) where i is the base.
Then that is the largest power where i^n is still n digits.

for base = 10 to inf, never satisfy. 10^n is n+1 digits.
...

'''

print(sum([3,2,3,4,6,10,21]))
