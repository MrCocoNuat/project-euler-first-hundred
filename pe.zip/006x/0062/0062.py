def digitTuple(n): 
    ans = [int(d) for d in str(n)]
    ans.sort()
    return tuple(ans)

perms = {} 
current = 0
minLength = 99999 #length of the smallest winning tuple(s)
winners = [] #stores the smallest winning tuples
digits = () #the digits that make up a cube
while len(digits) <= minLength:
    current += 1
    digits = digitTuple(current ** 3)
    perms[digits] = perms.get(digits,0) + 1
    if perms[digits] >= 5:
        print(digits, current**3, perms[digits])
        winners.append(digits)
        minLength = len(digits)


# From experimentation, the smallest tuples of digits for which 5 permutations are :

done = False
current = 1000 #this many digits in the cube root
while not done:
    current += 1 
    digits = digitTuple(current ** 3)
    if digits in winners:
        print("Smallest cube:", current**3)
        done = True
