e = [x for i in range(33,0,-1) for x in (1,2*i,1)] #33 triples plus the integer part are 100 elements
#The fraction components are stored backwards!

num, den = 0, 1 #the convergent fraction starts at 0/1

for n in e:
    num += n*den #add the component
    num, den = den, num #invert

num += 2*den #finally add the integer part
    
#print("%d/%d" % (num,den))

#sum digits of num
accum = 0
for char in str(num):
    accum += int(char)

print(accum)

