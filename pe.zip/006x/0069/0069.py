'''
for a very high n/phi(n) value, 

n/phi(n) = 1/[(1-1/p)(1-1/p)(1-1/p)....]

this means n must have a ton of small prime factors to make
each (1-1/p) term as small as possible, and their reciprocals
as large as possible. To achieve this, simply find the largest 
primorial less than 1M.

This is 17# = 510510

'''


print("see source")
print(2*3*5*7*11*13*17)
