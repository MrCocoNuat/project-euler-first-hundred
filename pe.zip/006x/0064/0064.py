'''
The kind of surd that is relevant is in the form a/(rt(b) - c)
This is stored as the tuple (a,b,c)

extract(surd) takes one of these tuples, and returns the tuple (f,g)
where f is the desired integer part of the input surd, and g is the reciprocal
of the remaining part of the input surd, which can be sent through extract again.
'''
import math

def extract(surd): #develop on a napkin
    a = surd[0]
    b = surd[1]
    c = surd[2]

    denom = (b - c*c)//a #gcd(a,denom) must equal a or something is wrong

    integer = int((b**0.5+c)/denom)
    reciprocalRemainder = (denom,b,integer*denom-c) #surd in the first form
    return (integer,reciprocalRemainder)


accum = 0 #count the number of odd periods

for i in range(1,10001):
    if (i - math.isqrt(i)**2) == 0:
        continue #don't do square numbers

    counter = 0 #tracks the period
    #print("Expanding square root of i =",i)

    #convert sqrt(i) into integer part + the reciprocal of 1/(sqrt(i) - int)
    surd = (1,i,math.isqrt(i))

    periodFinder = {}
    
    while True:
        counter += 1
                
        result = extract(surd)
        surd = result[1]
        if periodFinder.get(surd,0) == 0: #look for same surd appearing twice, then subtract the counter values where they appear to get the period
            periodFinder[surd] = counter
        else:
            if (counter - periodFinder[surd]) % 2 == 1:
                accum += 1
            break
            
        #print(result)
        
print(accum)

        


