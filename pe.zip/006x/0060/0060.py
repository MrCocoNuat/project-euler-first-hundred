'''
one prime may be 3
the others must be all 1mod3 or 2mod3

'''


MAX_PRIME = 10000 #largest prime desired

numbers = [x for i in range(6,MAX_PRIME+2,6) for x in (i-1,i+1)]
primes = [3] #using a wheel of 6 for simple speedups
#exclude 2 because that will never give prime concatenations

while numbers:
    if numbers[0]**2 > MAX_PRIME:
        primes, numbers = primes + numbers, []
    else:
        primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]
    
print("primes generated")

smallprimes = primes

def isPrime(n): #takes a string number
    n = int(n)
    if n % 2 == 0:
        return False
    factor = 3
    for p in primes:
        if (p*p > n):
            return True
        factor = p
        if n % factor == 0:
            return False
    while (factor*factor < n): #safety
        if n % factor == 0:
            return False
        factor += 2
    return True


results = []

mod3 = 0
for a in smallprimes:
    mod3 = a%3
    a = str(a)
    
    for b in smallprimes:
        
        if mod3 > 0 and b%3 != mod3:
            continue
        if mod3 == 0:
            mod3 = b%3
        b = str(b)
    
        if not (isPrime(a+b) and isPrime(b+a)):
            continue
            
        for c in smallprimes:

            if mod3 > 0 and c%3 != mod3:
                continue
            c = str(c)

            if not (isPrime(a+c) and isPrime(c+a)):
                continue
            if not (isPrime(b+c) and isPrime(c+b)):
                continue
            
            print(a,b,c)
            
            for d in smallprimes:
                
                if mod3 > 0 and d%3 != mod3:
                    continue
                d = str(d)
                
                if not (isPrime(a+d) and isPrime(d+a)):
                    continue
                if not (isPrime(b+d) and isPrime(d+b)):
                    continue
                if not (isPrime(c+d) and isPrime(d+c)):
                    continue
                
                for e in smallprimes:
                    
                    if mod3 > 0 and e%3 != mod3:
                        continue
                    e = str(e)
                    
                    if not (isPrime(a+e) and isPrime(e+a)):
                        continue
                    if not (isPrime(b+e) and isPrime(e+b)):
                        continue
                    if not (isPrime(c+e) and isPrime(e+c)):
                        continue
                    if not (isPrime(d+e) and isPrime(e+d)):
                        continue
                    
                    print(a,b,c,d,e,sum([int(n) for n in (a,b,c,d,e)]))
                    results.append((a,b,c,d,e))
                    exit() #yes, the first solution found happens to be correct

print(results)
