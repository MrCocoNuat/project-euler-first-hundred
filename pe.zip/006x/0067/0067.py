'''
Methodology:

Literally the same as 18
Dijkstra it!
'''

f = open("p067_triangle.txt","r")

triangle = [[int(q) for q in l[:-1].split(" ")] for l in f.readlines()][::-1]
#freaking list for comprehension, man...

for i in range(1,len(triangle)):
    for j in range(0,len(triangle[i])):
        triangle[i][j] = triangle[i][j] + max([triangle[i-1][j],triangle[i-1][j+1]])
        
print(triangle[len(triangle)-1][0])

