'''
Pell's equation:
xx - Dyy = 1

infinitely many solutions as long as D != n^2

This finds approximations to sqrt(D) ~= x/y
continued fraction approximations to this will *probably* solve Pell's
eventually, since they are supposed to be best possible approximations

Find the D<=1k for which the fundamental solution has largest x

requires an algorithm to find the contfrac expansion of arbitrary depth for any sqrt(D)

start: b/(sqrt(D)-c) stored as [D,b,c], starts out at [D,1,0]
rationalize: b/(sqrt(D)-c) = b(sqrt(D)+c)/(D-cc) = (sqrt(D)+c)/((D-cc)/b)    divisibility by b guaranteed
extract integer part: a + (sqrt(D)+c)/((D-cc)/b) - a
  the integer part a=int((sqrt(D)+c)/((D-cc)/b)) is added to the term list
reciprocals: a + 1/1/((sqrt(D)+c)/((D-cc)/b) - a)
next start: 1/((sqrt(D)+c)/((D-cc)/b) - a) = ((D-cc)/b)/((sqrt(D)+c - a(D-cc)/b) = [D,(D-cc)/b,-c+a(D-cc)/b]

therefore first turn sqrt(D) into a0 + 1/[D,1,a] 
find the next a=int(b(sqrt(D)+c)/(D-cc)), then turn [D,b,c] into [D,(D-cc)/b,-c+a(D-cc)/b] and repeat

'''
import math

MAX_D = 1000

squares = [n*n for n in range(1,math.isqrt(MAX_D) + 1)] #get the squares out

maxX = 0
maxD = 0
for D in range(1,MAX_D + 1):
    if D in squares:
        continue #no solution

    fracTerms = [] #stores the denom sequence
    
    print("approximating root of",D)
    
    a = int(math.sqrt(D))
    fracTerms.append(a)
    surd = [D,1,a]

    x,y = 1,1
    while x*x - D*y*y != 1:
        a = int( (math.sqrt(surd[0])+surd[2]) // ((surd[0]-surd[2]**2)/surd[1]) )
        surd = [surd[0], (surd[0]-surd[2]**2)//surd[1], -surd[2]+a*(surd[0]-surd[2]**2)//surd[1]]

        fracTerms.append(a)
        #print(fracTerms)


        x,y = fracTerms[-1],1 #start out here
        for term in fracTerms[::-1][1:]: #assemble the fraction
            x,y = term*x+y,x

        if x > maxX:
            maxX = x
            maxD = D

    print("sqrt",D,"~=",x,"/",y)
    print(fracTerms)

print()
print("largest fundamental x is for D=")
print(maxD)
