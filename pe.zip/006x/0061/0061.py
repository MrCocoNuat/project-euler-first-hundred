'''
start searching with octagon numbers since there are fewest

'''


octagons = []
for i in range(1,1000):
    result = i*(3*i-2)
    if result > 9999:
        break
    if result > 999:
        octagons.append(result)
octagonPre = [n//100 for n in octagons]
        
        
heptagons = []
for i in range(1,1000):
    result = i*(5*i-3)//2
    if result > 9999:
        break
    if result > 999:
        heptagons.append(result)
heptagonPre = [n//100 for n in heptagons]

hexagons = []
for i in range(1,1000):
    result = i*(2*i-1)
    if result > 9999:
        break
    if result > 999:
        hexagons.append(result)
hexagonPre = [n//100 for n in hexagons]

pentagons = []
for i in range(1,1000):
    result = i*(3*i-1)//2
    if result > 9999:
        break
    if result > 999:
        pentagons.append(result)
pentagonPre = [n//100 for n in pentagons]

tetragons = []
for i in range(1,1000):
    result = i*i
    if result > 9999:
        break
    if result > 999:
        tetragons.append(result)
tetragonPre = [n//100 for n in tetragons]

trigons = []
for i in range(1,1000):
    result = i*(i+1)//2
    if result > 9999:
        break
    if result > 999:
        trigons.append(result)
trigonPre = [n//100 for n in trigons]










chains = [] #stores a bunch of number chains
#in format [number, number, ..., number, remaining lists to pick from]

#chains will start filled with many 1-chains of the above format
#each step of chain propagation takes each chain and extends it with
#one number from one of the remaining lists stored in figures.
#one new chain with a longer length is generated for each possible
#chain continuation.
#at the end, chains will hold a bunch of 6-chains

for n in octagons: #populate chains with all octagonal number 1-chains
    figures = [(trigonPre, trigons), (tetragonPre, tetragons), (pentagonPre, pentagons), (hexagonPre, hexagons), (heptagonPre, heptagons)]
    #figures itself is a list of tuples of the form (prefix list, full list)
    #these are what the current chain has not visited yet
    chains.append([n,figures.copy()])

for i in range(5): #find chains of length 6
    newChains = []
    for chain in chains:
        suffix = chain[-2] % 100
        for l in chain[-1]:
            if suffix in l[0]: #suffix exists as prefix in that list somewhere
                newFigures = chain[-1].copy()
                newFigures.remove(l)
                assert len(newFigures) == 4 - i
                for number in l[1]: #search the list of full numbers
                    if suffix == number // 100:
                        newChain = chain[:-1].copy()
                        newChain.append(number)
                        newChain.append(newFigures)
                        newChains.append(newChain)

    chains = newChains
    print("%d-chains:" % (i+2),len(chains))

#at this point chains now contains a bunch of lists in the format:
# [AABB, BBCC, CCDD, DDEE, EEFF, FFGG, []]
#the last element is the empty figures list

#the chain is only a cycle if GG == AA
#now to close the chain into a cycle, there should only be one
for chain in chains:
    if chain[0] // 100 == chain[-2] % 100:
        print("found 6-cycle:")
        print(chain[:-1])
        print("sum")
        print(sum(chain[:-1]))
