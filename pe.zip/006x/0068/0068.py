'''
the string being 16 digits means that the 10 appears in the corners
or else 10 would appear twice, making the number of digits 17

_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

in general, keep high numbers on the outside so that they show up first
this also means minimize the sum of the 5 strings:

Assume 10, 9, 8, 7, 6 appear on the outside
the total sum of all 5 segments is 55+15 = 70, so each string is 14

start constructing the strings, with the third number in each the second of
the next string

Assume that 10 appears immediately after 6, the smallest external number
this would maximize the string nicely

6 _ _
    V
 10 _ _
      V
    _ _ _
        V
      _ _ _
          V
        _ _ _
            V
          6 _ _ (cyclic)

segment with 6 needs 8 more, segment with 10 only 4 more
The only way for these to share a number is (1,[3),5]

6 5 3
    V
 10 3 1
      V
    _ 1 _
        V
      _ _ _
          V
        _ _ 5
            V
          6 5 3
 
From there, try to place 9 as the next external node, since it is largest
remaining

6 5 3
    V
 10 3 1
      V
    9 1 4
        V
      _ 4 _
          V
        _ _ 5
            V
          6 5 3
 
then 8,

6 5 3
    V
 10 3 1
      V
    9 1 4
        V
      8 4 2
          V
        _ 2 5
            V
          6 5 3
 
and clearly placing 7 last works

6 5 3
    V
 10 3 1
      V
    9 1 4
        V
      8 4 2
          V
        7 2 5
            V
          6 5 3


So, the maximal 16-digit string is 

6531031914842725

'''


print("see source")
print("6531031914842725")
