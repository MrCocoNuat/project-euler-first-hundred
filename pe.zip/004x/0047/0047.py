'''
four consecutive integers each with four prime factors
'''
import math

def primeFactorCount(n):
    result = 0
    while n % 2 == 0:
        n //= 2
        result = 1
    factor = 3 #just a wheel of 2 is enough
    while n > 1:
        if n % factor == 0:
            result += 1
            while n % factor == 0:
                n //= factor
        factor += 2
    return result

current = 1
fourRun = 0

while fourRun < 4:
    count = primeFactorCount(current)
    if count == 4:
        fourRun += 1
    else:
        fourRun  = 0
    current += 1
        
print(current - 4) #first of the 4 consecutive numbers
