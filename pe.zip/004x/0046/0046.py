'''
Note that every odd number is either an odd composite or an odd prime + 0^2
'''

import math

MAX = 100000 #search for an odd number up to this

#if it turns out that the solution is above this number, just increase it

numbers = [x for i in range(6,MAX+2,6) for x in (i-1,i+1)]
primes = [3] #using a wheel of 6 for simple speedups

#REMOVE 2 SINCE IT IS NOT AN ODD PRIME

while numbers:
    primes.append(numbers[0])
    if numbers[0]**2 > MAX:
        primes, numbers = primes + numbers, []
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]
    
for i in range (3, MAX, 2):
    goldbach = False
    for prime in primes:
        if prime > i:
            break
        if math.isqrt((i - prime)//2)**2 - (i - prime)//2 == 0:
            goldbach = True
            break
    if not goldbach:
        print(i)
        break
