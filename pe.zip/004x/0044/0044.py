'''
P_(n+m) - P_n = 0.5m(6n - 3m - 1)

P_(n+m) + P_n = 0.5(6mn - 2n - 3mm - m)

0 = 1.5nn - 0.5n - P_n
n = (0.5 +- sqrt(0.25 + 6P_n))/3, only +

if P_n is an integer (yes) then sqrt(0.25 + 6P_n) + 0.5 
'''
import math

MAX_INDEX = 5000 #happens to be enough to find solution
pentagonals = [n*(3*n-1)//2 for n in range(1,MAX_INDEX + 1)]

def isPentagon(p_n):
    m = (0.5 + math.sqrt(0.25 + 6*p_n))
    return m % 3 == 0

for k in range(0,MAX_INDEX):
    for j in range(0,k):
        if isPentagon(pentagonals[k] - pentagonals[j]):
            if isPentagon(pentagonals[k] + pentagonals[j]):
                print("ok")
                print(pentagonals[k],pentagonals[j])
                print("diff")
                print(pentagonals[k] - pentagonals[j])

