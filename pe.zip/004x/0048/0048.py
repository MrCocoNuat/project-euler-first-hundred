modulus = 10**10 #10 digits

accum = 0

for i in range(1,1001):
    term = i
    for j in range(1,i):
        term = (term * i) % modulus
    accum = (accum + term) % modulus

print(accum)
