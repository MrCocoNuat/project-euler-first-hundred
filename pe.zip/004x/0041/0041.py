'''
any 9-digit pandigital is divisible by 9 (digit sum 45)
any 8-digit pandigital is divisible by 9 (digit sum 36)

presume that at least one 7-digit pandigital is prime
and only test those

it is not necessary to enumerate all primes, only need to check the
primality of the few pandigitals with a simpler test
'''
import math
import itertools

def isPrime(n):
    if n % 2 == 0 or n % 3 == 0:
        return False
    for i in range(5,math.isqrt(n)+1,6):
        if n % i == 0 or n % (i+2) == 0:
            return False
    return True
    
def intFromDigitList(l):
    result = 0
    for i in range(len(l)):
        result *= 10
        result += l[i]
    return result

for panList in itertools.permutations([7,6,5,4,3,2,1]):
    pandigital = intFromDigitList(panList)
    if isPrime(pandigital):
        print(pandigital)
        break
