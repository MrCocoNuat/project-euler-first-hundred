triangles = [n*(n+1)/2 for n in range(1,30)]
#a word with a score of 435 is really really long (ZZZZZZZZZZZZZZZZ = 416)
#and definitely not common, so this is long enough

import os

fh = open("/home/person/segfault/peuler/004x/0042/p042_words.txt","r") #may be executed from anywhere, so full path

def score(w):
    result = 0
    for ch in w:
        result += ord(ch) - ord("A") + 1
    return result

accum = 0
for word in fh.readline().replace("\"","").split(","):
    if score(word) in triangles:
        accum += 1
print(accum)

fh.close()
