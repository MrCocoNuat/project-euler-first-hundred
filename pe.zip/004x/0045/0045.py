import math

hexagonIndex = 1

done = 3 #find the third triple match, after 1 and 40755

def isTriangle(t_n):
    m = (-0.5 + math.sqrt(0.25 + 2*t_n))
    return m % 1 == 0

def isPentagon(p_n):
    m = (0.5 + math.sqrt(0.25 + 6*p_n))
    return m % 3 == 0

while done > 0:
    k = hexagonIndex * (2*hexagonIndex - 1)
    if isTriangle(k) and isPentagon(k):
        print("found")
        print(k)
        done -= 1
    hexagonIndex += 1
