#generate the 4 digit primes

numbers = [*range(2,10000)]
primes = []

while numbers:
    primes.append(numbers[0])
    numbers = [q for q in numbers[1:] if q % numbers[0] != 0]

primes = [p for p in primes if p > 999] #4 digit only

dictDigits = {p:{p//1000 , p//100 % 10, p//10 % 10, p % 10} for p in primes}

for i in primes:
    for j in primes:
        if i < j: #increasing sequence?
            if dictDigits[i] == dictDigits[j]: #same digits?
                if (2*j-i) in primes: #arithmetic sequence prime?
                    if dictDigits[i] == dictDigits[2*j-i]:
                        print("%d, %d, %d" % (i, j, 2*j-i))
                

#there are few enough examples of these sequences that filtering out those whose terms have the
#same set of digits but not the same multiset of digits (e.g. 1112 ! 1122) is easy enough. In fact,
#there are none where this is the case.
