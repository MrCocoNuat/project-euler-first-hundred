'''
complicated set of divisibility conditions for substrings of a 0-9 pandigital number

have fun proving all of them

brute force
'''

import itertools

accum = 0

for pandigital in itertools.permutations([0,1,2,3,4,5,6,7,8,9]):
    if pandigital[0] == 0:
        continue #no leading 0
    
    if (pandigital[3] % 2 == 0 #condition: divisible by 2
        and (pandigital[2] + pandigital[3] + pandigital[4]) % 3 == 0 #condition: divisible by 3
        and (pandigital[5]) % 5 == 0 # condition: divisible by 5
        and (pandigital[4]*3 + pandigital[5] + pandigital[6]*5) % 7 == 0 #condition: divisible by 7
        and (-pandigital[5] + pandigital[6] - pandigital[7]) % 11 == 0 #condition: divisible by 11
        and (-pandigital[6]*3 + pandigital[7] + pandigital[8]*4) % 13 == 0 #condition: divisible by 13
        and (-pandigital[7]*7 + pandigital[8] - pandigital[9]*5) % 17 == 0 #condition: divisible by7
    ):
        pandigital = [str(i) for i in pandigital]
        accum += int("".join(pandigital))
print(accum)
